/* ==========================================================
   Óptica Schanze — Comportamiento del sitio
   ========================================================== */
(() => {
  "use strict";

  const $ = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

  /* ---------- Toast (reemplaza alert) ---------- */
  const toastEl = $("#toast");
  let toastTimer;
  function toast(message, ms = 3200) {
    if (!toastEl) return;
    toastEl.textContent = message;
    toastEl.classList.add("is-visible");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove("is-visible"), ms);
  }

  /* ---------- Header: sombra al hacer scroll ---------- */
  const header = $(".header");
  const onScroll = () => header && header.classList.toggle("is-scrolled", window.scrollY > 8);
  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });

  /* ---------- Menú móvil ---------- */
  const menuBtn = $("#menuToggle");
  const nav = $("#nav");
  if (menuBtn && nav) {
    const closeMenu = () => {
      nav.classList.remove("is-open");
      menuBtn.setAttribute("aria-expanded", "false");
    };
    menuBtn.addEventListener("click", () => {
      const open = nav.classList.toggle("is-open");
      menuBtn.setAttribute("aria-expanded", String(open));
    });
    $$("a", nav).forEach((a) => a.addEventListener("click", closeMenu));
    document.addEventListener("keydown", (e) => e.key === "Escape" && closeMenu());
  }

  /* ---------- Enlace activo según sección visible ---------- */
  const navLinks = $$(".nav a[href^='#']");
  const sections = navLinks
    .map((a) => $(a.getAttribute("href")))
    .filter(Boolean);
  if ("IntersectionObserver" in window && sections.length) {
    const spy = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          navLinks.forEach((a) =>
            a.classList.toggle("is-active", a.getAttribute("href") === "#" + entry.target.id)
          );
        });
      },
      { rootMargin: "-45% 0px -50% 0px" }
    );
    sections.forEach((s) => spy.observe(s));
  }

  /* ---------- Animación de entrada ---------- */
  const revealEls = $$(".reveal");
  if ("IntersectionObserver" in window) {
    const io = new IntersectionObserver(
      (entries, obs) =>
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("is-visible");
            obs.unobserve(e.target);
          }
        }),
      { threshold: 0.12 }
    );
    revealEls.forEach((el) => io.observe(el));
  } else {
    revealEls.forEach((el) => el.classList.add("is-visible"));
  }

  /* ---------- Pestañas Rodenstock (accesibles) ---------- */
  const tabs = $$("[role='tab']");
  const panels = $$("[role='tabpanel']");
  function activateTab(tab, focus = false) {
    tabs.forEach((t) => {
      const selected = t === tab;
      t.setAttribute("aria-selected", String(selected));
      t.tabIndex = selected ? 0 : -1;
    });
    panels.forEach((p) => (p.hidden = p.id !== tab.getAttribute("aria-controls")));
    if (focus) tab.focus();
  }
  tabs.forEach((tab, i) => {
    tab.addEventListener("click", () => activateTab(tab));
    tab.addEventListener("keydown", (e) => {
      let next;
      if (e.key === "ArrowRight") next = tabs[(i + 1) % tabs.length];
      if (e.key === "ArrowLeft") next = tabs[(i - 1 + tabs.length) % tabs.length];
      if (e.key === "Home") next = tabs[0];
      if (e.key === "End") next = tabs[tabs.length - 1];
      if (next) {
        e.preventDefault();
        activateTab(next, true);
      }
    });
  });

  /* ---------- Selección de armazones ---------- */
  $$("[data-frame]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const name = btn.dataset.frame;
      const selected = btn.classList.toggle("is-selected");
      btn.textContent = selected ? "Seleccionado ✓" : "Seleccionar armazón";
      toast(selected ? `Armazón ${name} agregado a tu selección.` : `Armazón ${name} quitado.`);
    });
  });

  /* ---------- Imágenes: respaldo si falla la carga ---------- */
  $$(".card__media img").forEach((img) => {
    img.addEventListener("error", () => {
      img.style.display = "none";
      img.parentElement.insertAdjacentHTML(
        "beforeend",
        '<span style="position:absolute;inset:0;display:grid;place-items:center;font-size:13px;color:#6b7587">Imagen no disponible</span>'
      );
    });
  });

  /* ---------- Pack Low Cost ---------- */
  const lowcostBtn = $("#lowcostBtn");
  lowcostBtn &&
    lowcostBtn.addEventListener("click", () =>
      toast("Pack Low Cost seleccionado. Confirma por WhatsApp para continuar.")
    );

  /* ---------- Simulador de grosores (ojo derecho e izquierdo) ---------- */
  /*
   * Estimación referencial del espesor:
   *   flecha (sag) ≈ D² · P / (8000 · (n − 1))   [mm]
   *   Miopía (−):  espesor de borde = centro mínimo + flecha
   *   Hipermetropía (+): espesor de centro = borde mínimo + flecha
   * D = diámetro útil del cristal (mm). Se usa el meridiano de mayor potencia.
   *
   * Mientras no se ingresa una receta, la tabla muestra los valores de
   * EJEMPLO (editables aquí). Al escribir una receta se calcula con la fórmula.
   */
  const DIAMETRO_MM = 60;
  const CENTRO_MIN_MM = 1.5; // cristales negativos
  const BORDE_MIN_MM = 1.0;  // cristales positivos

  const LENTES_GROSOR = [
    { id: "low",  n: 1.50 },
    { id: "std",  n: 1.60 },
    { id: "prem", n: 1.67 }
  ];
  const EJEMPLO_GROSOR = {
    od: { low: 2.0, std: 1.8, prem: 1.5 },
    oi: { low: 2.0, std: 1.8, prem: 1.5 }
  };

  const camposGrosor = {
    od: [$("#esferaOD"), $("#cilindroOD")],
    oi: [$("#esferaOI"), $("#cilindroOI")]
  };
  const estadoGrosor = $("#grosorEstado");

  function calcularEspesor(s, c, n) {
    const pMax = Math.abs(s) >= Math.abs(s + c) ? s : s + c; // meridiano de mayor potencia
    const flecha = (DIAMETRO_MM ** 2 * Math.abs(pMax)) / (8000 * (n - 1));
    if (Math.abs(pMax) < 0.25) return { mm: CENTRO_MIN_MM, tipo: "centro" };
    if (pMax < 0) return { mm: CENTRO_MIN_MM + flecha, tipo: "borde" };
    return { mm: BORDE_MIN_MM + flecha, tipo: "centro" };
  }

  function pintarCelda(ojo, lenteId, texto, tipo) {
    const td = document.querySelector(`[data-lente="${lenteId}"][data-ojo="${ojo}"]`);
    if (!td) return;
    td.innerHTML = texto === "—"
      ? "<span class='cell-empty'>—</span>"
      : `<strong>${texto}</strong><small>${tipo}</small>`;
  }

  function actualizarGrosores() {
    if (!$("#tablaGrosor")) return;
    const hayReceta = Object.values(camposGrosor).some((par) =>
      par.some((el) => el && el.value.trim() !== "")
    );

    LENTES_GROSOR.forEach((lente) => {
      ["od", "oi"].forEach((ojo) => {
        if (!hayReceta) {
          pintarCelda(ojo, lente.id, `${EJEMPLO_GROSOR[ojo][lente.id].toFixed(1)} mm`, "borde / centro");
          return;
        }
        const [elS, elC] = camposGrosor[ojo];
        const vacio = !elS.value.trim() && !elC.value.trim();
        if (vacio) return pintarCelda(ojo, lente.id, "—", "");
        const r = calcularEspesor(parseFloat(elS.value) || 0, parseFloat(elC.value) || 0, lente.n);
        pintarCelda(ojo, lente.id, `${r.mm.toFixed(1)} mm`, r.tipo);
      });
    });

    if (estadoGrosor) {
      estadoGrosor.textContent = hayReceta
        ? "Calculado según la receta ingresada."
        : "Valores de ejemplo. Ingresa tu receta para calcular el espesor de cada ojo.";
    }
  }
  Object.values(camposGrosor).flat().forEach((el) => el && el.addEventListener("input", actualizarGrosores));
  actualizarGrosores();

  /* ---------- Cotizador Rodenstock ---------- */
  /*
   * Todos los valores salen de COTIZADOR (CLP). Para agregar más opciones a un
   * menú, súmalas en su lista "opciones".
   *   - 1.er menú de cada línea: valor base (p = precio total de esa opción).
   *   - Menús siguientes: p = recargo sobre el valor base (0 = incluido).
   *   - extra: filtro opcional que se suma al total.
   */
  const COTIZADOR = [
    {
      id: "multi", etiqueta: "Gama alta", tono: "gold",
      titulo: "1. Línea Rodenstock Multifocal", corto: "Multifocal",
      campos: [
        { nombre: "Diseño multifocal", opciones: [
          { n: "Progresiv", p: 250000 },
          { n: "Multigresiv", p: 300000 },
          { n: "Impresión", p: 380000 }
        ] },
        { nombre: "Índice de reducción", opciones: [
          { n: "Índice 1.5 (Base)", p: 0 },
          { n: "Índice 1.6", p: 50000 },
          { n: "Índice 1.67", p: 100000 }
        ] }
      ],
      extra: { n: "Filtro Protec Balance", p: 50000 }
    },
    {
      id: "stock", etiqueta: "Stock / Tradicional", tono: "green",
      titulo: "2. Rodenstock Monofocal (Stock)", corto: "Monofocal stock",
      campos: [
        { nombre: "Alternativa de stock", opciones: [
          { n: "Índice 1.5 - Antirreflejo", p: 45000 },
          { n: "Índice 1.6 - Antirreflejo", p: 60000 }
        ] }
      ],
      extra: { n: "Filtro Azul Selectivo", p: 40000 }
    },
    {
      id: "cosmolit", etiqueta: "Tecnología biométrica", tono: "blue",
      titulo: "3. Monofocal Biométrico (Cosmolit)", corto: "Monofocal biométrico",
      campos: [
        { nombre: "Versión Cosmolit", opciones: [
          { n: "Cosmolit 1.5", p: 100000 },
          { n: "Cosmolit 1.6", p: 140000 },
          { n: "Cosmolit 1.67", p: 240000 },
          { n: "Cosmolit 1.74 - Alemania", p: 300000 }
        ] }
      ],
      extra: { n: "Protec Balance Selectiva", p: 40000 }
    }
  ];

  const clp = new Intl.NumberFormat("es-CL", { style: "currency", currency: "CLP", maximumFractionDigits: 0 });
  const fmt = (n) => clp.format(n);
  const etiquetaOpcion = (o, i) => (o.p > 0 ? `${o.n} (${i === 0 ? "" : "+"}${fmt(o.p)})` : o.n);

  // Ventana del cotizador
  const dlg = $("#cotizador");
  const cards = $("#cotizadorCards");
  if (dlg && cards) {
    cards.innerHTML = COTIZADOR.map((l) => {
      const campos = l.campos.map((c, ci) => `
        <div class="field">
          <label for="cot-${l.id}-${ci}">${c.nombre}</label>
          <select id="cot-${l.id}-${ci}" data-campo="${ci}">
            ${c.opciones.map((o, oi) => `<option value="${oi}">${etiquetaOpcion(o, ci)}</option>`).join("")}
          </select>
        </div>`).join("");
      return `
      <article class="quote" data-linea="${l.id}">
        <div class="quote__head">
          <div>
            <span class="quote__tag quote__tag--${l.tono}">${l.etiqueta}</span>
            <h3>${l.titulo}</h3>
          </div>
          <div class="quote__value"><small>Valor final estimado</small><strong data-total>$0</strong></div>
        </div>
        <div class="quote__body">
          ${campos}
          <label class="check">
            <input type="checkbox" data-extra>
            <span>${l.extra.n}</span><em>+${fmt(l.extra.p)}</em>
          </label>
        </div>
        <a class="btn btn--ghost" data-wsp href="https://wa.me/56949399873" target="_blank" rel="noopener">Cotizar esta opción por WhatsApp</a>
      </article>`;
    }).join("");

    function calcular(card) {
      const l = COTIZADOR.find((x) => x.id === card.dataset.linea);
      let total = 0;
      const detalle = [l.titulo];
      $$("select[data-campo]", card).forEach((sel, ci) => {
        const o = l.campos[ci].opciones[Number(sel.value)];
        total += o.p;
        detalle.push(`${l.campos[ci].nombre}: ${o.n}`);
      });
      if ($("[data-extra]", card).checked) { total += l.extra.p; detalle.push(l.extra.n); }
      $("[data-total]", card).textContent = fmt(total);
      const msg = `Hola, quiero cotizar:\n${detalle.map((d) => "- " + d).join("\n")}\nValor estimado: ${fmt(total)}`;
      $("[data-wsp]", card).href = "https://wa.me/56949399873?text=" + encodeURIComponent(msg);
    }
    $$(".quote", cards).forEach((card) => {
      card.addEventListener("change", () => calcular(card));
      calcular(card);
    });

    const abrir = () => (typeof dlg.showModal === "function" ? dlg.showModal() : dlg.setAttribute("open", ""));
    const cerrar = () => (typeof dlg.close === "function" ? dlg.close() : dlg.removeAttribute("open"));
    $$("[data-abrir-cotizador]").forEach((b) => b.addEventListener("click", abrir));
    $$("[data-cerrar-cotizador]").forEach((b) => b.addEventListener("click", cerrar));
    dlg.addEventListener("click", (e) => { if (e.target === dlg) cerrar(); });
  }

  /* ---------- Agenda por WhatsApp ---------- */
  const agForm = $("#agendaForm");
  const agPreview = $("#agendaPreview");
  const agEstado = $("#agendaEstado");
  const WSP_NUMERO = "56949399873";

  if (agForm && agPreview) {
    const agFecha = $("#agFecha");
    const agHorario = $("#agHorario");
    const hoyISO = () => {
      const d = new Date();
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    };
    if (agFecha) agFecha.min = hoyISO();

    /*
     * Horas disponibles, cada 30 minutos.
     * BLOQUES_ATENCION: [inicio, fin] en horas (24 h). Entre bloques no se agenda
     * (aquí: cerrado por almuerzo de 14:00 a 15:00). La última hora de cada bloque
     * es 30 minutos antes de su fin.
     */
    const BLOQUES_ATENCION = [[10, 14], [15, 19]];
    const PASO_MIN = 30;

    function llenarHorarios() {
      if (!agHorario) return;
      const actual = agHorario.value;
      const esHoy = agFecha && agFecha.value === hoyISO();
      const ahora = new Date();
      const minAhora = ahora.getHours() * 60 + ahora.getMinutes();
      agHorario.innerHTML = '<option value="">Indiferente</option>';
      BLOQUES_ATENCION.forEach(([ini, fin]) => {
        for (let m = ini * 60; m < fin * 60; m += PASO_MIN) {
          const hh = String(Math.floor(m / 60)).padStart(2, "0");
          const mm = String(m % 60).padStart(2, "0");
          const opt = new Option(`${hh}:${mm}`, `${hh}:${mm}`);
          if (esHoy && m <= minAhora) opt.disabled = true; // no ofrecer horas que ya pasaron
          agHorario.add(opt);
        }
      });
      const previa = Array.from(agHorario.options).find((o) => o.value === actual && !o.disabled);
      agHorario.value = previa ? actual : "";
    }
    llenarHorarios();
    if (agFecha) agFecha.addEventListener("change", llenarHorarios);

    const limpiar = (t) => String(t || "").replace(/\*/g, "").replace(/\s+/g, " ").trim();
    const fechaLegible = (iso) => {
      if (!iso) return "";
      const [a, m, d] = iso.split("-");
      return `${d}-${m}-${a}`;
    };
    const escapar = (t) => t.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

    // Devuelve las líneas del mensaje: [etiqueta, valor]
    function datosAgenda() {
      const v = (n) => limpiar(agForm.elements[n].value);
      return [
        ["Nombre", v("nombre")],
        ["Teléfono", v("telefono")],
        ["Sucursal", v("sucursal")],
        ["Motivo", v("motivo")],
        ["Fecha preferida", fechaLegible(agForm.elements["fecha"].value)],
        ["Hora preferida", v("horario")],
        ["Comentarios", v("comentarios")]
      ].filter(([, valor]) => valor);
    }

    // En WhatsApp, *texto* se ve en negrita
    const mensajeTexto = () =>
      "Hola, quiero agendar una cita.\n\n" + datosAgenda().map(([e, v]) => `${e}: *${v}*`).join("\n");

    const mensajeHtml = () =>
      "Hola, quiero agendar una cita.<br><br>" +
      (datosAgenda().map(([e, v]) => `${e}: <strong>${escapar(v)}</strong>`).join("<br>") ||
        "<span class='wsp-hint'>Tus datos aparecerán aquí…</span>");

    const pintarVista = () => (agPreview.innerHTML = mensajeHtml());
    agForm.addEventListener("input", pintarVista);
    agForm.addEventListener("change", pintarVista);
    pintarVista();

    agForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const url = `https://wa.me/${WSP_NUMERO}?text=${encodeURIComponent(mensajeTexto())}`;
      window.open(url, "_blank", "noopener");
      if (agEstado) agEstado.textContent = "Abrimos WhatsApp con tu mensaje listo. Solo presiona enviar.";
    });

    // Botones "Agendar hora" de cada sucursal: preseleccionan la sucursal
    $$("[data-sucursal]").forEach((a) =>
      a.addEventListener("click", () => {
        agForm.elements["sucursal"].value = a.dataset.sucursal;
        pintarVista();
      })
    );
  }

  /* ---------- Video del taller ---------- */
  const videoBtn = $("#videoBtn");
  videoBtn &&
    videoBtn.addEventListener("click", () =>
      toast("El video del taller estará disponible próximamente.")
    );

  /* ---------- Formulario de convenio ---------- */
  const form = $("#convenioForm");
  const status = $("#formStatus");
  if (form && status) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      status.classList.remove("is-error");

      const empresa = form.elements["empresa"].value.trim();
      const contacto = form.elements["contacto"].value.trim();
      const personas = form.elements["personas"].value.trim();

      if (!empresa || !contacto) {
        status.classList.add("is-error");
        status.textContent = "Completa el nombre de la empresa y los datos de contacto.";
        return;
      }

      // Se deriva la solicitud a WhatsApp Central (no hay backend en este sitio).
      const msg =
        `Hola, quiero solicitar un convenio de oftalmología móvil.%0A` +
        `Empresa: ${encodeURIComponent(empresa)}%0A` +
        `Contacto: ${encodeURIComponent(contacto)}%0A` +
        `Colaboradores: ${encodeURIComponent(personas || "No indicado")}`;
      window.open(`https://wa.me/56949399873?text=${msg}`, "_blank", "noopener");

      status.textContent = "Solicitud preparada. Continúa el envío en WhatsApp.";
      form.reset();
    });
  }
})();